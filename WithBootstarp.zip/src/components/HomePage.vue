<template>
    <div class="home">
        <span class="H-text">{{Header}}</span>
        <div class="container">
            <div class="row justify-content-md-center">
                
                <div class="col-md-auto">
                    <h5>Create Account?</h5>
                </div>
                <div class="col col-lg-2">
                    <button type="button" class="btn btn-outline-primary btn-sm" @click="goToRegisterPage">Sign Up</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import router from '../router'
    export default {
        name : 'home',
        data() {
            return {
                Header: "Welcome!!"
            }
        },
        methods: {
            goToRegisterPage() {
                router.push({ name:"Register" });
            }
        }
    }
</script>

<style scoped>
    .H-text {
        font-size: 50px;
    }
</style>