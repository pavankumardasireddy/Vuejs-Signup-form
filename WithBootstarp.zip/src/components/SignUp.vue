<template>
    <div id="signup">
        <h3>{{title}}</h3>
        <div class="signup">
            
        </div>
    </div>
</template>

<script>
    export default {
        name: 'signUp',
        data() {
            return {
                title:'Create Account'
            }
        }
    }
</script>

<style>

</style>
